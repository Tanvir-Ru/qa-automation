package base;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class JuiceShopPage {

	WebDriver driver;
    WebDriverWait wait;

    public JuiceShopPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void openJuiceShop() {
        driver.get("https://juice-shop.herokuapp.com");
    }

    public void dismissWelcomePopup() {
        WebElement dismissButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".close-dialog")));
        dismissButton.click();
    }

    public void login(String email, String password) {
        WebElement accountButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("navbarAccount")));
        accountButton.click();
        WebElement loginButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("navbarLoginButton")));
        loginButton.click();
        WebElement emailField = wait.until(ExpectedConditions.elementToBeClickable(By.id("email")));
        emailField.sendKeys(email);
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys(password);
        WebElement loginSubmitButton = driver.findElement(By.id("loginButton"));
        loginSubmitButton.click();
    }

    public void addItemToBasket() {
        WebElement addToBasketButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("button[aria-label='Add to Basket']")));
        addToBasketButton.click();
    }

    public void proceedToCheckout() {
        WebElement checkoutButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("navbarBasket")));
        checkoutButton.click();
    }

    public void addNewAddress(String country, String name, String mobile, String zip, String address, String city, String state) {
        WebElement addNewAddressButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector(".mat-primary > .mat-button-wrapper")));
        addNewAddressButton.click();
        WebElement countryField = wait.until(ExpectedConditions.elementToBeClickable(By.id("mat-input-2")));
        countryField.sendKeys(country);
        WebElement nameField = driver.findElement(By.id("mat-input-3"));
        nameField.sendKeys(name);
        WebElement mobileNumberField = driver.findElement(By.id("mat-input-4"));
        mobileNumberField.sendKeys(mobile);
        WebElement zipCodeField = driver.findElement(By.id("mat-input-5"));
        zipCodeField.sendKeys(zip);
        WebElement addressField = driver.findElement(By.id("mat-input-6"));
        addressField.sendKeys(address);
        WebElement cityField = driver.findElement(By.id("mat-input-7"));
        cityField.sendKeys(city);
        WebElement stateField = driver.findElement(By.id("mat-input-8"));
        stateField.sendKeys(state);
        WebElement submitButton = driver.findElement(By.cssSelector(".mat-primary"));
        submitButton.click();
    }

    public void searchForItem(String itemName) {
        WebElement searchField = wait.until(ExpectedConditions.elementToBeClickable(By.id("searchQuery")));
        searchField.sendKeys(itemName);
        WebElement searchButton = driver.findElement(By.cssSelector("button[aria-label='Search']"));
        searchButton.click();
    }

    public List<WebElement> getSearchResults() {
        return wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(".product-name")));
    }
}
	

