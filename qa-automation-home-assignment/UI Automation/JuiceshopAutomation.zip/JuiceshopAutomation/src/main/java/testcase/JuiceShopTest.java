package testcase;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.JuiceShopPage;

public class JuiceShopTest {
	WebDriver driver;
    JuiceShopPage juiceShopPage;

    @BeforeClass
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Tanvir\\Downloads\\Compressed\\chromedriver_win32");
        driver = new ChromeDriver();
        juiceShopPage = new JuiceShopPage(driver);
    }

    @Test
    public void testLoginAddToBasketCheckout() {
        juiceShopPage.openJuiceShop();
        juiceShopPage.dismissWelcomePopup();
        juiceShopPage.login("iamtester.cse@gmail.com", "D$sAgPIKVM0C");
        juiceShopPage.addItemToBasket();
        juiceShopPage.proceedToCheckout();
        juiceShopPage.addNewAddress("USA", "Test User", "1234567890", "12345", "123 Test St", "Test City", "Test State");
    }

    @Test
    public void testSearchFunctionality() {
        juiceShopPage.openJuiceShop();
        juiceShopPage.searchForItem("apple");
        List<WebElement> products = juiceShopPage.getSearchResults();

        long appleProductsCount = products.stream()
                .filter(product -> product.getText().toLowerCase().contains("apple"))
                .count();
        long bananaProductsCount = products.stream()
                .filter(product -> product.getText().toLowerCase().contains("banana"))
                .count();

        Assert.assertEquals(appleProductsCount, 2, "There should be 2 apple products.");
        Assert.assertEquals(bananaProductsCount, 0, "There should be no banana products.");
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

}
